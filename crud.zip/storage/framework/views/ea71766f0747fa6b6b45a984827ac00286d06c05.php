<!--Vista de los diferentes registros-->


 

<?php $__env->startSection("cabecera"); ?>

<b>LECTURA DE REGISTROS</b>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contenido"); ?>

<!-- Se crea una fila con los titulos de la tabla -->
<table>

<tr>
	<td><b> Nombre </b></td>
	<td><b> Apellido </b> </td>
	<td><b> Email </b></td>
	<td><b> Edad </b></td>
	<td><b> Telefono </b></td>
</tr>

<!-- Se crea una fila con cada uno de las propiedades del objeto persona -->
	<?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><a href="<?php echo e(route("personas.edit",$persona->id)); ?>"><?php echo e($persona->Nombre); ?></a></td> <!-- Para la primer propiedad (Nombre), creamos enlaces hacia la vista de su correspondiente registro paa editar o eliminar,-->
	<td><?php echo e($persona->Apellido); ?></td>
	<td><?php echo e($persona->Email); ?></td>
	<td><?php echo e($persona->Edad); ?></td>
	<td><?php echo e($persona->Telefono); ?></td>	
</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\crud\resources\views/personas/index.blade.php ENDPATH**/ ?>