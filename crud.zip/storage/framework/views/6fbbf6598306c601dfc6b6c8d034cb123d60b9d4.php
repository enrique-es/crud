<?php $__env->startSection("cabecera"); ?>
INTERVALO DE REGISTROS
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contenido"); ?>

<table>
    <?php $__currentLoopData = $tiempo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <dir><?php echo e($valor["id"]); ?> </dir> </td> 
        <td> <dir><?php echo e($valor["Fecha"]); ?> </dir> </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("../layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\crud\resources\views/personas/intervalo.blade.php ENDPATH**/ ?>