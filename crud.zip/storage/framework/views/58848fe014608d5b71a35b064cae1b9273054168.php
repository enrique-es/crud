<!-- Plantilla base para las distintas páginas aunque en realidad no se utilizo algun formato o estilo para las diferentes secciones, simplemente sirve como referencia para su escalabilidad -->


<!DOCTYPE html>
<html>
<head>
	<title>CRUD</title>

<style>
	.cabecera{
		text-align: center;
		font-size: x-large;
		margin-bottom: 100px;
	}	
</style>

<style>
	.contenido{
		margin-bottom: 10px;
	}	
</style>

</head>

<body>
<div class = "cabecera"> </div>
	<?php echo $__env->yieldContent("cabecera"); ?>

<div class = "contenido"> </div>
	<?php echo $__env->yieldContent("contenido"); ?>

<div class = "pie"> </div>
	<?php echo $__env->yieldContent("pie"); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\proyectos\laravel\crud\resources\views////layouts/plantilla.blade.php ENDPATH**/ ?>