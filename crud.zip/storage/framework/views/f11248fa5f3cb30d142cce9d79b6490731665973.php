<!-- Vista del formulario para editar los valores de las variables la cual nos permite editar registros o eliminarlos por completo

Incluimos dos formularios uno normal para postear la informacion y otro con el metodo hidden para poder
eliminar algun registro

 -->




<?php $__env->startSection("cabecera"); ?>
EDITAR REGISTROS
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contenido"); ?>

	<form method="post" action="/personas/<?php echo e($persona->id); ?>" >

	<table>
		<tr>
			<td> Nombre: </td>
			<td>
		<input type="text" name="Nombre" value="<?php echo e($persona->Nombre); ?>">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="_method" value="PUT">
			</td>
		</tr>
		<tr>
			<td> Apellido: </td>
			<td>
		<input type="text" name="Apellido" value="<?php echo e($persona->Apellido); ?>">
			</td>
		</tr>
		<tr>
			<td> Email: </td>
			<td>
		<input type="text" name="Email" value="<?php echo e($persona->Email); ?>">
			</td>
		</tr>
		<tr>
			<td> Edad: </td>
			<td>
		<input type="text" name="Edad" value="<?php echo e($persona->Edad); ?>">
			</td>
		</tr>
		<tr>
			<td> Teléfono: </td>
			<td>
		<input type="text" name="Telefono" value="<?php echo e($persona->Telefono); ?>">
			</td>
		</tr>

		<tr>
			<td>
		<input type="submit" name="enviar" value="Enviar">
		<input type="reset" name="Borrar" value="Borrar">
			</td>
		</tr>
	</table>
	</form>

	<form method="post" action="/personas/<?php echo e($persona->id); ?>" >
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="_method" value="delete"> 
		<input type="submit" name="Borrar" value="Eliminar">
	</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\crud\resources\views/personas/edit.blade.php ENDPATH**/ ?>