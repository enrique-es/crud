<!-- A traves de esta vista podemos mostramos mediante solicitud url de un ID especifico que querramos ver 
es decir, debemos anotar en la dirección URL despues de   http://127.0.0.1:8000/personas/   el valor del id interesado.

-->



<?php $__env->startSection("cabecera"); ?>

<b>MOSTRAR REGISTROS</b>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("contenido"); ?>

<?php echo e($persona->Nombre); ?>

<?php echo e($persona->Apellido); ?>

<?php echo e($persona->Email); ?>

<?php echo e($persona->Edad); ?>

<?php echo e($persona->Telefono); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection("pie"); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("../layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\crud\resources\views/personas/show.blade.php ENDPATH**/ ?>